from django.contrib import admin

# Aquí podrás registrar tus modelos en el admin de Django
# cuando desarrolles la aplicación en el futuro.